from django.db import models
from django.core.validators import RegexValidator
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
import random

# --- UserDetail Model ---
class UserDetail(models.Model):
    phone_regex = RegexValidator(
        regex=r'^\d{10}$',
        message="Phone number must be exactly 10 digits."
    )

    user_id = models.CharField(
        max_length=5,
        unique=True,
        db_index=True,
        verbose_name='User ID',
        help_text='5-digit unique identifier',
        default='00000'  # Will be overwritten in save()
    )
    name = models.CharField(max_length=100, default='Unknown', blank=False)
    email = models.EmailField(blank=True, null=True, default=None)
    phone_number = models.CharField(
        validators=[phone_regex],
        max_length=10,
        unique=True,
        db_index=True,
        verbose_name='Phone Number',
        blank=False,
        null=False,
    )
    photo = models.ImageField(upload_to='photos/', null=True, blank=True, default=None)
    timestamp = models.DateTimeField(default=timezone.now)
    to_meet = models.CharField(max_length=100, default='N/A')
    purpose = models.CharField(max_length=200, default='N/A')
    place = models.CharField(max_length=200, default='N/A')

    class Meta:
        ordering = ['-timestamp']
        verbose_name = 'User Detail'
        verbose_name_plural = 'User Details'

    def __str__(self):
        return f"{self.name} ({self.user_id}) | Created: {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}"

    def save(self, *args, **kwargs):
        # Auto-generate unique 5-digit user_id if not set or default
        if not self.user_id or self.user_id == '00000':
            while True:
                random_id = str(random.randint(10000, 99999))
                if not UserDetail.objects.filter(user_id=random_id).exists():
                    self.user_id = random_id
                    break
        super().save(*args, **kwargs)


# --- UserVisitLog Model ---
class UserVisitLog(models.Model):
    user = models.ForeignKey(
        'UserDetail',
        on_delete=models.CASCADE,
        related_name='visit_logs',
        verbose_name=_('User'),
    )

    user_id_copy = models.CharField(max_length=100, blank=True, null=True, default='')
    name = models.CharField(max_length=100, blank=True, null=True, default='')
    to_meet = models.CharField(max_length=100, default='N/A', blank=True, null=True)
    purpose = models.CharField(max_length=200, default='N/A', blank=True, null=True)
    place = models.CharField(max_length=200, default='N/A', blank=True, null=True)
    login_time = models.DateTimeField(blank=True, null=True)
    logout_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        ordering = ['-login_time']
        verbose_name = _('User Visit Log')
        verbose_name_plural = _('User Visit Logs')

    def __str__(self):
        login_str = self.login_time.strftime('%Y-%m-%d %H:%M:%S') if self.login_time else "N/A"
        logout_str = self.logout_time.strftime('%Y-%m-%d %H:%M:%S') if self.logout_time else "N/A"
        return f"{self.name} ({self.user_id_copy}) | Login: {login_str} | Logout: {logout_str}"

    def __repr__(self):
        return f"<UserVisitLog {self.user_id_copy} login={self.login_time} logout={self.logout_time}>"

    def save(self, *args, **kwargs):
        if self.user:
            if not self.user_id_copy:
                self.user_id_copy = self.user.user_id
            if not self.name:
                self.name = self.user.name
            # Only fill if blank or None; preserve updated values if any
            if not self.to_meet:
                self.to_meet = self.user.to_meet
            if not self.place:
                self.place = self.user.place
            if not self.purpose:
                self.purpose = self.user.purpose
        super().save(*args, **kwargs)
