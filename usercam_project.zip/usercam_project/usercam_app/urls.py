from django.urls import path
from . import views

urlpatterns = [
    path('', views.page_one, name='page_one'),
    path('form', views.user_form, name='user_form'),
]
