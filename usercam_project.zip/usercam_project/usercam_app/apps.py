from django.apps import AppConfig


class UsercamAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "usercam_app"
