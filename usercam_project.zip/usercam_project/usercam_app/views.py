from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.utils.timezone import now
from django.core.files.base import ContentFile
from .models import UserDetail, UserVisitLog
import base64
import pytz


def format_datetime_str(dt_obj):
    """
    Format datetime object to string in IST timezone, e.g., '09:34pm'.
    Returns empty string if dt_obj is None.
    """
    if not dt_obj:
        return ''
    try:
        ist = pytz.timezone('Asia/Kolkata')
        dt_obj = dt_obj.astimezone(ist)
        return dt_obj.strftime('%I:%M%p').lower()
    except Exception:
        return str(dt_obj)


@csrf_exempt
def page_one(request):
    user = None
    phone_number = None
    message = None
    last_log = None
    visit_logs = []
    active_sessions_exist = False

    if request.method == 'GET' and 'phone_number' in request.GET:
        phone_number = request.GET.get('phone_number', '').strip()
        try:
            user = UserDetail.objects.get(phone_number__iexact=phone_number)
            visit_logs = user.visit_logs.order_by('-login_time')

            # Format login and logout times for all logs
            for log in visit_logs:
                log.login_time_formatted = format_datetime_str(log.login_time)
                log.logout_time_formatted = format_datetime_str(log.logout_time)

            last_log = visit_logs[0] if visit_logs else None

            # Check if any active session exists (logout_time is None or invalid)
            active_sessions_exist = any(
                not log.logout_time or str(log.logout_time).strip().lower() in ['', 'n/a', 'none']
                for log in visit_logs
            )

        except UserDetail.DoesNotExist:
            # User not found, redirect to registration form
            return redirect('/form')

    elif request.method == 'POST':
        action = request.POST.get('action')
        phone_number = request.POST.get('phone_number', '').strip()

        if not phone_number:
            message = "Phone number is required."
        else:
            try:
                user = UserDetail.objects.get(phone_number__iexact=phone_number)
                timestamp = now()

                if action == 'login':
                    to_meet = request.POST.get('to_meet', '').strip() or 'N/A'
                    purpose = request.POST.get('purpose', '').strip() or 'N/A'
                    place = request.POST.get('place', '').strip() or 'N/A'

                    # Create a new login log entry
                    UserVisitLog.objects.create(
                        user=user,
                        to_meet=to_meet,
                        purpose=purpose,
                        place=place,
                        login_time=timestamp,
                        logout_time=None
                    )
                    message = "Login time recorded."

                elif action == 'logout':
                    # Find last active login (without logout time)
                    last_log = user.visit_logs.filter(logout_time__isnull=True).order_by('-login_time').first()
                    if last_log:
                        last_log.logout_time = timestamp
                        last_log.save()
                        message = "Logout time recorded."
                    else:
                        message = "No active login session found."

                else:
                    message = "Invalid action."

                # Refresh visit logs after the action
                visit_logs = user.visit_logs.order_by('-login_time')
                for log in visit_logs:
                    log.login_time_formatted = format_datetime_str(log.login_time)
                    log.logout_time_formatted = format_datetime_str(log.logout_time)

                last_log = visit_logs[0] if visit_logs else None

                active_sessions_exist = any(
                    not log.logout_time or str(log.logout_time).strip().lower() in ['', 'n/a', 'none']
                    for log in visit_logs
                )

            except UserDetail.DoesNotExist:
                return redirect('/form')

    return render(request, 'page1.html', {
        'user': user,
        'phone_number': phone_number,
        'message': message,
        'last_log': last_log,
        'visit_logs': visit_logs,
        'active_sessions_exist': active_sessions_exist,
    })


@csrf_exempt
def user_form(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        photo_data = request.POST.get('photo')
        timestamp = now()

        photo = None
        if photo_data:
            try:
                format_part, imgstr = photo_data.split(';base64,')
                ext = format_part.split('/')[-1]
                photo = ContentFile(base64.b64decode(imgstr), name=f"{phone_number}.{ext}")
            except Exception as e:
                print(f"[Photo Decode Error] {e}")

        try:
            # Update existing user if phone number exists
            user = UserDetail.objects.get(phone_number=phone_number)
            user.name = name
            user.email = email
            user.timestamp = timestamp
            if photo:
                user.photo = photo
            user.save()
        except UserDetail.DoesNotExist:
            # Create new user record
            user = UserDetail.objects.create(
                name=name,
                email=email,
                phone_number=phone_number,
                timestamp=timestamp,
                photo=photo
            )

        return render(request, 'form.html', {
            'success': True,
            'generated_id': user.user_id
        })

    return render(request, 'form.html')
